import { HomePage } from "./pages/home";
import { ScanPage } from "./pages/scan";
import { LeaderboardPage } from "./pages/leaderboard";
import { AboutPage } from "./pages/about";

const routes = {
    "/": HomePage,
    "/scan": ScanPage,
    "/leaderboard": LeaderboardPage,
    "/about": AboutPage,
};

function render() {
    const app = document.querySelector("#app");

    if (!app) {
        console.error("#app element not found.");
        return;
    }

    const path = window.location.hash.replace("#", "") || "/";
    const page = routes[path] || HomePage;

    app.innerHTML = page();
}

export function router() {
    window.addEventListener("hashchange", render);
    render();
}