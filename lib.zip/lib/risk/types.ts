export interface TokenAnalysis {
  liquidityLocked: boolean
  lpBurned: boolean

  mintAuthority: boolean
  freezeAuthority: boolean

  creatorHolding: number
  topHolder: number

  liquidityUsd: number
  volume24h: number

  ageDays: number
}

export type Severity = "success" | "warning" | "danger"

export interface RiskCheck {
  id: string

  title: string

  description: string

  passed: boolean

  severity: Severity

  score: number
}

export interface RiskResult {
  score: number

  level: "LOW" | "MEDIUM" | "HIGH" | "EXTREME"

  checks: RiskCheck[]
}

export interface RuleResult {
  check: RiskCheck
}