import { RiskCheck } from "./types"

export function success(
  id: string,
  title: string,
  description: string
): RiskCheck {

  return {

    id,

    title,

    description,

    passed: true,

    severity: "success",

    score: 0,

  }

}

export function danger(
  id: string,
  title: string,
  description: string,
  score: number
): RiskCheck {

  return {

    id,

    title,

    description,

    passed: false,

    severity: "danger",

    score,

  }

}