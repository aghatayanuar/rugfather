import { RiskCheck } from "./types"

export function addCheck(
  checks: RiskCheck[],
  id: string,
  title: string,
  passed: boolean,
  score: number,
  description: string
) {

  checks.push({
    id,

    title,

    passed,

    score: passed ? 0 : score,

    description,

    severity: passed ? "success" : "danger",
  })

}