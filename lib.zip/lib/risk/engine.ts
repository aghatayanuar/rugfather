import { RiskRules } from "./rules"
import { addCheck } from "./scoring"

import { RiskCheck, RiskResult, TokenAnalysis } from "./types"

export function analyzeToken(
  token: TokenAnalysis
): RiskResult {

  const checks: RiskCheck[] = []

  addCheck(
    checks,

    "mint-authority",

    "Mint Authority",

    !token.mintAuthority,

    RiskRules.mintAuthority.score,

    token.mintAuthority
      ? "Mint authority masih aktif."
      : "Mint authority sudah dicabut."
  )

  addCheck(
    checks,

    "freeze-authority",

    "Freeze Authority",

    !token.freezeAuthority,

    RiskRules.freezeAuthority.score,

    token.freezeAuthority
      ? "Freeze authority masih aktif."
      : "Freeze authority sudah dicabut."
  )

  const score = checks.reduce(
    (total, check) => total + check.score,
    0
  )

  let level: RiskResult["level"] = "LOW"

  if (score >= 76)
    level = "EXTREME"

  else if (score >= 51)
    level = "HIGH"

  else if (score >= 21)
    level = "MEDIUM"

  return {

    score,

    level,

    checks,

  }

}