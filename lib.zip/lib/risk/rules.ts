export const RiskRules = {

  mintAuthority: {

    id: "mint-authority",

    title: "Mint Authority",

    score: 20,

  },

  freezeAuthority: {

    id: "freeze-authority",

    title: "Freeze Authority",

    score: 15,

  },

  liquidityUnlocked: {

    id: "liquidity",

    title: "Liquidity Locked",

    score: 25,

  },

  lpNotBurned: {

    id: "lp",

    title: "LP Burned",

    score: 15,

  },

}